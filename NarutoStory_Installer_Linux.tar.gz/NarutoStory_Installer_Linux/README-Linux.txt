Naruto Story Installer for Linux
================================

Requirements:
- a 64-bit Linux distribution
- Python 3
- Wine (the game engine is currently distributed as a Windows executable)

Installation:
1. Extract NarutoStory_Installer_Linux.tar.gz.
2. Open a terminal in the extracted folder.
3. Run: bash install.sh
4. After installation, open "Naruto Story" from your applications menu.

The installer downloads the OpenGL x64 client from:
https://narutostory.net/download/client/

If the primary server is unavailable, the installer automatically retries from:
https://eu.narutostory.net/download/client/

Default locations:
Game: ~/Games/Naruto Story
Launcher: ~/.local/bin/narutostory
Desktop entry: ~/.local/share/applications/narutostory.desktop
Logs: ~/.local/state/narutostory/install.log and game.log
