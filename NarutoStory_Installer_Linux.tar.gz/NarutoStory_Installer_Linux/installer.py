#!/usr/bin/env python3

import base64
import binascii
import hashlib
import json
import os
import pathlib
import shutil
import ssl
import sys
import time
import urllib.parse
import urllib.request
import zipfile


PROXY_TLS_ERROR_MARKERS = (
    "wrong_version_number",
    "wrong version number",
    "unknown protocol",
    "packet length too long",
    "record layer failure",
)
DIRECT_URL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
USE_DIRECT_CONNECTION = False


class SecureConnectionError(RuntimeError):
    """A readable HTTPS error that keeps certificate verification enabled."""


def exception_chain(error):
    pending = [error]
    seen = set()
    while pending:
        current = pending.pop(0)
        if current is None or id(current) in seen:
            continue
        seen.add(id(current))
        yield current
        pending.extend(
            (
                getattr(current, "reason", None),
                getattr(current, "__cause__", None),
                getattr(current, "__context__", None),
            )
        )


def is_proxy_tls_error(error):
    details = " | ".join(str(item).lower() for item in exception_chain(error))
    return any(marker in details for marker in PROXY_TLS_ERROR_MARKERS)


def is_tls_error(error):
    chain = list(exception_chain(error))
    if any(isinstance(item, ssl.SSLError) for item in chain):
        return True
    details = " | ".join(str(item).lower() for item in chain)
    return any(
        marker in details
        for marker in (
            "[ssl:",
            "certificate verify failed",
            "tlsv1 alert",
            "ssl handshake",
        )
    )


def short_network_error(error):
    chain = list(exception_chain(error))
    detail = str(chain[-1] if chain else error).strip().replace("\n", " ")
    return detail[:240] or type(error).__name__


def secure_connection_error(error, direct_error=None):
    technical = short_network_error(error)
    if direct_error is not None:
        technical += f"; direct retry: {short_network_error(direct_error)}"
    return SecureConnectionError(
        "A secure HTTPS connection could not be established. A proxy, VPN, "
        "antivirus HTTPS scanner, or network filter may be interfering. "
        "Disable it temporarily or try a mobile hotspot, then run the installer "
        f"again. Technical details: {technical}"
    )


def open_request(request, timeout=60):
    global USE_DIRECT_CONNECTION

    if USE_DIRECT_CONNECTION:
        try:
            return DIRECT_URL_OPENER.open(request, timeout=timeout)
        except Exception as error:
            if is_tls_error(error):
                raise secure_connection_error(error) from error
            raise

    try:
        return urllib.request.urlopen(request, timeout=timeout)
    except Exception as error:
        if not is_proxy_tls_error(error):
            if is_tls_error(error):
                raise secure_connection_error(error) from error
            raise

        print(
            "A proxy-related TLS issue was detected; trying a direct secure connection.",
            file=sys.stderr,
            flush=True,
        )
        try:
            response = DIRECT_URL_OPENER.open(request, timeout=timeout)
        except Exception as direct_error:
            raise secure_connection_error(error, direct_error) from direct_error

        USE_DIRECT_CONNECTION = True
        print(
            "Direct secure connection established; continuing without the proxy.",
            file=sys.stderr,
            flush=True,
        )
        return response


def report(message, current, total, zenity):
    percent = int(current * 100 / total)
    if zenity:
        print(f"# {message}", flush=True)
        print(percent, flush=True)
    else:
        print(f"[{current}/{total}] {percent}%: {message}", flush=True)


def safe_path(game_dir, raw_path):
    if not isinstance(raw_path, str):
        raise ValueError("Manifest path must be a string.")

    candidate = raw_path.replace("\\", "/").strip()
    path = pathlib.PurePosixPath(candidate)
    if (
        not candidate
        or path.is_absolute()
        or any(part in ("", ".", "..") for part in path.parts)
    ):
        raise ValueError(f"Unsafe manifest path: {raw_path!r}")
    if any(ord(character) < 32 or ord(character) == 127 for character in candidate):
        raise ValueError("Manifest path contains a control character.")

    target = (game_dir / pathlib.Path(*path.parts)).resolve()
    if target != game_dir and game_dir not in target.parents:
        raise ValueError("Manifest path escapes the installation directory.")
    return candidate, target


def expected_hash(item):
    value = (
        item.get("sha256")
        or item.get("sha256sum")
        or item.get("checksum_sha256")
        or item.get("hash")
    )
    if not isinstance(value, str):
        return None

    value = value.strip()
    if len(value) == 64 and all(
        character in "0123456789abcdefABCDEF" for character in value
    ):
        return value.lower()

    try:
        decoded = base64.b64decode(value, validate=True).decode("ascii").strip()
    except (binascii.Error, UnicodeDecodeError):
        return None

    if len(decoded) == 64 and all(
        character in "0123456789abcdefABCDEF" for character in decoded
    ):
        return decoded.lower()
    return None


def safe_extract(archive_path, destination):
    destination = destination.resolve()
    with zipfile.ZipFile(archive_path, "r") as archive:
        for member in archive.infolist():
            name = member.filename.replace("\\", "/")
            if not name:
                continue

            member_path = pathlib.PurePosixPath(name)
            if member_path.is_absolute() or any(
                part == ".." for part in member_path.parts
            ):
                raise RuntimeError(f"Archive contains an unsafe path: {name}")

            mode = member.external_attr >> 16
            if (mode & 0o170000) == 0o120000:
                raise RuntimeError(f"Archive contains a symbolic link: {name}")

            target = (destination / pathlib.Path(*member_path.parts)).resolve()
            if target != destination and destination not in target.parents:
                raise RuntimeError(
                    f"Archive entry escapes the installation directory: {name}"
                )

        archive.extractall(destination)


def read_manifest(url, headers):
    request = urllib.request.Request(url, headers=headers)
    with open_request(request, timeout=60) as response:
        manifest = json.load(response)
    if not isinstance(manifest, list):
        raise RuntimeError("The server manifest is invalid.")
    return manifest


def build_entries(manifest, game_dir):
    entries = []
    for item in manifest:
        if not isinstance(item, dict) or "path" not in item:
            continue

        relative, target = safe_path(game_dir, item["path"])
        basename = pathlib.PurePosixPath(relative).name
        if (
            basename.startswith("nsclient_")
            and basename.endswith(".zip")
            and basename != "nsclient_gl_x64.zip"
        ):
            continue

        size = item.get("size")
        if isinstance(size, str) and size.isdigit():
            size = int(size)
        if not isinstance(size, int) or size < 0:
            size = None

        entries.append(
            {
                "path": relative,
                "target": target,
                "size": size,
                "sha256": expected_hash(item),
            }
        )

    if not entries:
        raise RuntimeError("The server manifest contains no client files.")
    return entries


def verify_download(path, entry):
    if entry["size"] is not None and path.stat().st_size != entry["size"]:
        raise RuntimeError("Downloaded size does not match the manifest.")

    if entry["sha256"]:
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest().lower() != entry["sha256"]:
            raise RuntimeError("Downloaded SHA-256 does not match the manifest.")


def download_entry(entry, base_urls, headers):
    target = entry["target"]
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(target.name + ".part")
    last_error = None

    for base_url in base_urls:
        url = base_url + urllib.parse.quote(entry["path"], safe="/")
        for attempt in range(5):
            try:
                request = urllib.request.Request(url, headers=headers)
                with open_request(request, timeout=60) as response:
                    with partial.open("wb") as output:
                        shutil.copyfileobj(response, output, length=64 * 1024)
                verify_download(partial, entry)
                os.replace(partial, target)
                return
            except Exception as error:
                last_error = error
                partial.unlink(missing_ok=True)
                if isinstance(error, SecureConnectionError):
                    break
                if attempt < 4:
                    time.sleep(min(2**attempt, 8))

    raise RuntimeError(f"Failed to download {entry['path']}: {last_error}")


def read_manifest_from_endpoints(endpoints, headers):
    last_error = None
    for index, (manifest_url, base_url) in enumerate(endpoints):
        try:
            manifest = read_manifest(manifest_url, headers)
            ordered_base_urls = [base_url]
            ordered_base_urls.extend(
                candidate_base
                for candidate_index, (_, candidate_base) in enumerate(endpoints)
                if candidate_index != index
            )
            return manifest, ordered_base_urls
        except Exception as error:
            last_error = error
            if index + 1 < len(endpoints):
                print(
                    "Primary download server unavailable; trying backup server.",
                    file=sys.stderr,
                    flush=True,
                )
    raise RuntimeError(f"Unable to download the server manifest: {last_error}")


def main():
    args = sys.argv[1:]
    zenity = args[:1] == ["--zenity"]
    if zenity:
        args = args[1:]
    if len(args) not in (3, 5):
        raise SystemExit(
            "Usage: installer.py [--zenity] PRIMARY_MANIFEST PRIMARY_BASE "
            "[FALLBACK_MANIFEST FALLBACK_BASE] GAME_DIRECTORY"
        )

    if len(args) == 3:
        manifest_url, base_url, game_dir_text = args
        endpoints = [(manifest_url, base_url)]
    else:
        (
            manifest_url,
            base_url,
            fallback_manifest_url,
            fallback_base_url,
            game_dir_text,
        ) = args
        endpoints = [
            (manifest_url, base_url),
            (fallback_manifest_url, fallback_base_url),
        ]

    game_dir = pathlib.Path(game_dir_text).expanduser().resolve()
    game_dir.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": "Mozilla/5.0 (NarutoStoryInstaller-Linux)"}

    manifest, base_urls = read_manifest_from_endpoints(endpoints, headers)
    entries = build_entries(manifest, game_dir)
    total = len(entries)

    for index, entry in enumerate(entries, start=1):
        filename = pathlib.PurePosixPath(entry["path"]).name
        report(f"Downloading {filename}", index - 1, total, zenity)
        download_entry(entry, base_urls, headers)

        if entry["path"].lower().endswith(".zip"):
            report(f"Extracting {filename}", index - 1, total, zenity)
            safe_extract(entry["target"], entry["target"].parent)
            entry["target"].unlink()

    report("Finishing installation", total, total, zenity)


if __name__ == "__main__":
    main()
