#!/usr/bin/env bash

set -Eeuo pipefail

MANIFEST_URL="https://narutostory.net/download/client/manifest.json"
BASE_URL="https://narutostory.net/download/client/"
FALLBACK_MANIFEST_URL="https://eu.narutostory.net/download/client/manifest.json"
FALLBACK_BASE_URL="https://eu.narutostory.net/download/client/"
GAME_DIR="${HOME}/Games/Naruto Story"
BIN_DIR="${HOME}/.local/bin"
LAUNCHER_PATH="${BIN_DIR}/narutostory"
APPLICATIONS_DIR="${HOME}/.local/share/applications"
DESKTOP_FILE="${APPLICATIONS_DIR}/narutostory.desktop"
DATA_DIR="${HOME}/.local/share/narutostory"
WINE_PREFIX="${DATA_DIR}/wineprefix"
STATE_DIR="${XDG_STATE_HOME:-${HOME}/.local/state}/narutostory"
LOG_FILE="${STATE_DIR}/install.log"
LAUNCH_LOG="${STATE_DIR}/game.log"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALLER_PY="${SCRIPT_DIR}/installer.py"
ICON_SOURCE="${SCRIPT_DIR}/NarutoStory.png"
ICON_DIR="${HOME}/.local/share/icons/hicolor/256x256/apps"
ICON_PATH="${ICON_DIR}/narutostory.png"

mkdir -p "${STATE_DIR}"
touch "${LOG_FILE}"

if command -v zenity >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    USE_ZENITY=1
else
    USE_ZENITY=0
fi

log() {
    printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >>"${LOG_FILE}"
}

show_info() {
    log "$1"
    if [ "${USE_ZENITY}" -eq 1 ]; then
        zenity --info --title="Naruto Story Installer" --text="$1" --width=460
    else
        printf '\n%s\n\n' "$1"
    fi
}

show_error() {
    log "ERROR: $1"
    if [ "${USE_ZENITY}" -eq 1 ]; then
        zenity --error --title="Naruto Story Installer" --text="$1" --width=500
    else
        printf '\nERROR: %s\nSee the log: %s\n\n' "$1" "${LOG_FILE}" >&2
    fi
}

confirm_install() {
    local message
    message="Naruto Story will be installed in:
${GAME_DIR}

The launcher will be added to your applications menu.

The Windows game client runs through Wine."

    if [ "${USE_ZENITY}" -eq 1 ]; then
        zenity --question \
            --title="Naruto Story Installer" \
            --text="${message}" \
            --ok-label="Install" \
            --cancel-label="Cancel" \
            --width=500
    else
        printf '%s\n\nContinue? [Y/n] ' "${message}"
        read -r answer
        case "${answer}" in
            n|N|no|NO) return 1 ;;
            *) return 0 ;;
        esac
    fi
}

find_wine() {
    local candidate
    for candidate in wine64 wine; do
        if command -v "${candidate}" >/dev/null 2>&1; then
            command -v "${candidate}"
            return 0
        fi
    done
    return 1
}

wine_install_hint() {
    if command -v apt-get >/dev/null 2>&1; then
        printf '%s' "sudo apt update && sudo apt install wine64"
    elif command -v dnf >/dev/null 2>&1; then
        printf '%s' "sudo dnf install wine"
    elif command -v pacman >/dev/null 2>&1; then
        printf '%s' "sudo pacman -S wine"
    elif command -v zypper >/dev/null 2>&1; then
        printf '%s' "sudo zypper install wine"
    else
        printf '%s' "Install Wine using your distribution's package manager."
    fi
}

install_launcher() {
    local wine_bin="$1"
    local quoted_game_dir quoted_wine_prefix quoted_log quoted_wine

    mkdir -p "${BIN_DIR}" "${APPLICATIONS_DIR}" "${ICON_DIR}" "${WINE_PREFIX}"

    printf -v quoted_game_dir '%q' "${GAME_DIR}"
    printf -v quoted_wine_prefix '%q' "${WINE_PREFIX}"
    printf -v quoted_log '%q' "${LAUNCH_LOG}"
    printf -v quoted_wine '%q' "${wine_bin}"

    {
        printf '%s\n' '#!/usr/bin/env bash'
        printf 'GAME_DIR=%s\n' "${quoted_game_dir}"
        printf 'WINE_PREFIX=%s\n' "${quoted_wine_prefix}"
        printf 'LOG_FILE=%s\n' "${quoted_log}"
        printf 'WINE_BIN=%s\n' "${quoted_wine}"
        cat <<'LAUNCHER'
GAME_EXE="${GAME_DIR}/nsclient_gl_x64.exe"

if [ ! -f "${GAME_EXE}" ]; then
    if command -v zenity >/dev/null 2>&1; then
        zenity --error --title="Naruto Story" --text="The game client was not found. Run Naruto Story Installer again."
    else
        printf 'The game client was not found. Run Naruto Story Installer again.\n' >&2
    fi
    exit 1
fi

if [ ! -x "${WINE_BIN}" ]; then
    WINE_BIN="$(command -v wine64 || command -v wine || true)"
fi
if [ -z "${WINE_BIN}" ]; then
    if command -v zenity >/dev/null 2>&1; then
        zenity --error --title="Naruto Story" --text="Wine was not found. Install Wine and try again."
    else
        printf 'Wine was not found. Install Wine and try again.\n' >&2
    fi
    exit 1
fi

mkdir -p "$(dirname "${LOG_FILE}")" "${WINE_PREFIX}"
export WINEPREFIX="${WINE_PREFIX}"
export WINEDEBUG="-all"
cd "${GAME_DIR}"
nohup "${WINE_BIN}" "${GAME_EXE}" >>"${LOG_FILE}" 2>&1 &
LAUNCHER
    } >"${LAUNCHER_PATH}"
    chmod 755 "${LAUNCHER_PATH}"

    if [ -f "${ICON_SOURCE}" ]; then
        install -m 644 "${ICON_SOURCE}" "${ICON_PATH}"
    fi

    cat >"${DESKTOP_FILE}" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Naruto Story
Comment=Play Naruto Story
Exec=${LAUNCHER_PATH}
Icon=narutostory
Terminal=false
Categories=Game;
StartupNotify=true
DESKTOP
    chmod 644 "${DESKTOP_FILE}"

    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database "${APPLICATIONS_DIR}" >>"${LOG_FILE}" 2>&1 || true
    fi
}

download_client() {
    local statuses

    set +e
    if [ "${USE_ZENITY}" -eq 1 ]; then
        python3 "${INSTALLER_PY}" \
            --zenity \
            "${MANIFEST_URL}" "${BASE_URL}" \
            "${FALLBACK_MANIFEST_URL}" "${FALLBACK_BASE_URL}" "${GAME_DIR}" \
            2>>"${LOG_FILE}" |
            zenity --progress \
                --title="Naruto Story Installer" \
                --text="Preparing download..." \
                --percentage=0 \
                --auto-close \
                --no-cancel \
                --width=520
        statuses=("${PIPESTATUS[@]}")
    else
        python3 "${INSTALLER_PY}" \
            "${MANIFEST_URL}" "${BASE_URL}" \
            "${FALLBACK_MANIFEST_URL}" "${FALLBACK_BASE_URL}" "${GAME_DIR}" \
            2>&1 | tee -a "${LOG_FILE}"
        statuses=("${PIPESTATUS[@]}")
    fi
    set -e

    return "${statuses[0]}"
}

main() {
    local wine_bin

    log "=== Naruto Story Installer started ==="

    if ! confirm_install; then
        log "Installation cancelled."
        exit 0
    fi

    if ! command -v python3 >/dev/null 2>&1; then
        show_error "Python 3 is required. Install the python3 package and run this installer again."
        exit 1
    fi

    if [ ! -f "${INSTALLER_PY}" ]; then
        show_error "The installer package is incomplete. Extract all files and try again."
        exit 1
    fi

    if ! wine_bin="$(find_wine)"; then
        show_error "Wine is required to run the current Windows game client.

Install it, then open this installer again:
$(wine_install_hint)"
        exit 1
    fi

    if ! download_client; then
        show_error "The game could not be installed.

If the log mentions a secure HTTPS connection, disable any VPN, proxy, or antivirus HTTPS scanning, or try a mobile hotspot.

Details:
${LOG_FILE}"
        exit 1
    fi

    if [ ! -f "${GAME_DIR}/nsclient_gl_x64.exe" ]; then
        show_error "The OpenGL x64 game executable was not found after installation."
        exit 1
    fi

    install_launcher "${wine_bin}"
    show_info "Naruto Story was installed successfully.

Open Naruto Story from your applications menu to play."
}

main "$@"
