ObjC.import("Foundation");

function run(argv) {
    if (argv.length !== 1) {
        throw new Error("Expected one manifest path.");
    }

    const manifestPath = $(argv[0]).stringByStandardizingPath;
    const source = $.NSString.stringWithContentsOfFileEncodingError(
        manifestPath,
        $.NSUTF8StringEncoding,
        null
    );
    if (!source) {
        throw new Error("Could not read manifest.");
    }

    const manifest = JSON.parse(ObjC.unwrap(source));
    if (!Array.isArray(manifest)) {
        throw new Error("Manifest root must be an array.");
    }

    return manifest.map(function (entry) {
        if (!entry || typeof entry.path !== "string") {
            throw new Error("Invalid manifest entry.");
        }
        const path = entry.path.replace(/\\/g, "/");
        if (/[\u0000-\u001f\u007f]/.test(path)) {
            throw new Error("Manifest path contains a control character.");
        }
        const size = Number(entry.size);
        if (!Number.isSafeInteger(size) || size < 0) {
            throw new Error("Invalid file size for " + path);
        }
        const hash = typeof entry.hash === "string" ? entry.hash : "";
        const encodedPath = encodeURI(path).replace(/#/g, "%23").replace(/\?/g, "%3F");
        return [path, String(size), hash, encodedPath].join("\t");
    }).join("\n");
}
