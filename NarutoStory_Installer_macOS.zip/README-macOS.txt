Naruto Story Installer for macOS
================================

1. Unpack the ZIP file.
2. Control-click "NarutoStory_Installer_macOS.app" and choose Open.
3. Confirm installation and follow the prompts.
4. After installation, launch "Naruto Story" from your Applications folder.

The Naruto Story game engine is currently distributed as a Windows executable.
This installer runs the OpenGL x64 client through Wine. On Apple Silicon Macs,
Rosetta 2 is also required. The installer can add Rosetta and can add Wine when
Homebrew is already installed.

Files are downloaded from:
https://narutostory.net/download/client/

If the primary server is unavailable, the installer automatically retries from:
https://eu.narutostory.net/download/client/

Default locations:
Game: ~/Games/Naruto Story
Launcher: ~/Applications/Naruto Story.app
Logs: ~/Library/Logs/NarutoStoryInstaller.log and NarutoStory.log
